<?php


$xeonto = 'dravast1000@gmail.com';

$adminPass = 'password';



?>